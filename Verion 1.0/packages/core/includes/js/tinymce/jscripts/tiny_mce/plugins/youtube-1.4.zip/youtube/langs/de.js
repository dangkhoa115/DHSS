tinyMCE.addI18n('de.youtube',{
	desc : 'Einfügen von YouTube-Videos'
});
