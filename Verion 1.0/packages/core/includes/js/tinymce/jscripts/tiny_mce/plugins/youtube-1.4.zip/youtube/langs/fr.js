tinyMCE.addI18n('fr.youtube',{
	desc : 'Insérer une vidéo YouTube'
});
