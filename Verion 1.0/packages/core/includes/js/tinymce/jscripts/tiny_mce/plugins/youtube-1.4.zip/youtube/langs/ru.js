tinyMCE.addI18n('ru.youtube',{
	desc : 'Вставить видео YouTube'
});
