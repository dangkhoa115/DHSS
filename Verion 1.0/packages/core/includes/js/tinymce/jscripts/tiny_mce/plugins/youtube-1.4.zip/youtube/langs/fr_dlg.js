tinyMCE.addI18n('fr.youtube_dlg',{
    title : "Insérez une vidéo YouTube",
    instr : "Format du lien de partage : <br /> http://youtu.be/xxxxxxxx <br /> ou <br /> http://www.youtube.com/watch?v=xxxxxxxx",
    ytID : "Lien de partage",
    ytW : "Largeur",
    ytH : "Hauteur",
    autoplay: "Autoplay",
    relvideo: "Vidéos similaires",
    hd:"Visionner en HD",
    yes:"Oui",
    no:"Non"
});