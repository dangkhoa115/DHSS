tinyMCE.addI18n('ru.youtube_dlg',{
    title : "Вставить видео YouTube",
    instr : "Формат ссылки: <br /> http://youtu.be/xxxxxxxx <br /> или <br /> http://www.youtube.com/watch?v=xxxxxxxx",
    ytID : "Ссылка",
    ytW : "Ширина",
    ytH : "Высота",
    autoplay: "Автозапуск",
    relvideo: "Похожие видео",
    hd:"В формате HD",
    yes:"Да",
    no:"Нет"
});