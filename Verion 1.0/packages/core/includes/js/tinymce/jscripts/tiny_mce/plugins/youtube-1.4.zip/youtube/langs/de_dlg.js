tinyMCE.addI18n('de.youtube_dlg',{
    title : "Einfügen von YouTube-Videos",
    instr : "Link-Format : <br /> http://youtu.be/xxxxxxxx <br /> oder <br/> http://www.youtube.com/watch?v=xxxxxxxx",
    ytID : "Youtube-Link",
    ytW : "Breite",
    ytH : "Hoehe",
    autoplay: "Automatische Wiedergabe?",
    relvideo: "Verwandte Videos anzeigen?",
    hd:"In HD abspielen?",
    yes:"Ja",
    no:"Nein"
});